# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain-games package.',
    'long_description': '# **BRAIN-GAMES**\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AlexanderLarriva/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AlexanderLarriva/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/380ec53218587343ca34/maintainability)](https://codeclimate.com/github/AlexanderLarriva/python-project-49/maintainability) [![Test Coverage](https://api.codeclimate.com/v1/badges/380ec53218587343ca34/test_coverage)](https://codeclimate.com/github/AlexanderLarriva/python-project-49/test_coverage)\n___\n\n## Description.\n\n<font size = ”1”> A set of mini-games launched from the console.\nThe set contains the following games:\n- Brain-even\n  \n  The essence of the game is as follows: a random number is shown to the user. And he needs to answer "yes" if the number is even, or "no" if it is odd.\n  #### [*Demonstration of the Brain-even game*](https://asciinema.org/a/547043)\n\n- Brain-calc\n  \n  The essence of the game is as follows: the user is shown a random mathematical expression, for example 35 + 16, which needs to be calculated and written down the correct answer.\n  #### [*Demonstration of the Brain-calc game*](https://asciinema.org/a/547741)\n\n- Brain-gcd\n  \n  The essence of the game is as follows: the user is shown two random numbers, for example, 25 50. The user must calculate and enter the greatest common divisor of these numbers.\n  #### [*Demonstration of the Brain-gcd game*](https://asciinema.org/a/547980)\n\n- Brain-prime\n  \n  The essence of the game is as follows: the player is shown a number. The player must determine whether the number is prime and answer "yes" or "no".\n  #### [*Demonstration of the Brain-prime game*](https://asciinema.org/a/548446)\n  \n- Brain-progression\n  \n  The essence of the game is as follows: the player is shown a series of numbers forming an arithmetic progression, replacing any of the numbers with two dots. The player must determine this number.\n  #### [*Demonstration of the Brain-progression game*](https://asciinema.org/a/548355)\n  \nGames are run on the command line by calling commands: **brain-even, brain-calc, brain-gcd, brain-prime, brain-progression**.\n</font>\n\n### Installation procedure.\n\nThe game is installed by the command:\n\n`python3 -m pip install --user git+https://github.com/AlexanderLarriva/python-project-49.git`\n\nRemoved by the command:\n\n`python3 -m pip uninstall hexlet-code`\n\n#### [*Demonstration of the installation and removal of the game*](https://asciinema.org/a/548973)',
    'author': 'Alexander Shangin',
    'author_email': 'alarriva@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/AlexanderLarriva/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
