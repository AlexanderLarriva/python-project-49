#!/usr/bin/env python3
import brain_games.games.engine_calc


def main():
    brain_games.games.engine_calc.run_play()


if __name__ == '__main__':
    main()
