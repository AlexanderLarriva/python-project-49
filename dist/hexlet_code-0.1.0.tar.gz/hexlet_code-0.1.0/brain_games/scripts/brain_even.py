import brain_games.engine_even


def main():
    brain_games.engine_even.run_play()


if __name__ == '__main__':
    main()
