### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlexanderLarriva/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AlexanderLarriva/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/380ec53218587343ca34/maintainability)](https://codeclimate.com/github/AlexanderLarriva/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/380ec53218587343ca34/test_coverage)](https://codeclimate.com/github/AlexanderLarriva/python-project-49/test_coverage)

### Sharing a link asciinema Brain-even
https://asciinema.org/a/BZGkZ1XKhLcvCMHHjeHGVZYii

### Sharing a link asciinema Brain-calc
https://asciinema.org/a/547741

### Sharing a link asciinema Brain-gcd
https://asciinema.org/a/547980

### Sharing a link asciinema Brain-progression
https://asciinema.org/a/548355

### Sharing a link asciinema Brain-prime
https://asciinema.org/a/548446