import brain_games.games.engine_prime


def main():
    brain_games.games.engine_prime.run_play()


if __name__ == '__main__':
    main()
